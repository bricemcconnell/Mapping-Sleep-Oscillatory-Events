classdef EventType
   enumeration
      SlowWaves, Spindles
   end
end
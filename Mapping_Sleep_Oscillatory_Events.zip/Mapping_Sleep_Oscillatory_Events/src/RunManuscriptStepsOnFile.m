function RunManuscriptStepsOnFile(params)
swswaitbar ( '**disable**' );
[~, edf_name, ~] = fileparts(params.EdfFile);

info = LoadEDF(params.EdfFile, params.RescaleOpt);

temp_event_chan_list = split(params.EventChannel,'|');
for l = 1:length(temp_event_chan_list)
    temp_event_chan = find(strcmpi(strtrim(info.ChannelList), strtrim(temp_event_chan_list{l})));
    if ~isempty(temp_event_chan)
        break
    end
end
if isempty(temp_event_chan)
    warning('Channel file %s not found in channel file. Skipping file %s', params.EventChannel, params.EdfFile)
    return
end
event_chan = temp_event_chan;

%Process channel data
channel_file = PrimaryProcessing(info, event_chan, params.ChannelOutputDir);

clear info;
clear channels;

%%Get mapped channel data
mapChanData = matfile(channel_file,'Writable',false);
chan_index = find(mapChanData.Channel==event_chan);
sr = mapChanData.SamplingRate(chan_index,1);
params.WTParam.EndTime = mapChanData.Duration;
params.BandpassParams.Channel = event_chan;
params.BandpassParams.MapChanIndex = chan_index;

%% Load Staging Data
%update staging params with correct sample rate
params.StagingParams.DataSamplingRate = sr;
staging_param = params.StagingParams;

%compute the time length
final_time = length(mapChanData.RawRun(chan_index,:,1))/sr;%seconds length of data

%Load data from staging file
st_data = LoadStaging(params.StageFile, final_time, staging_param, sr);

%Map stages selected by user to stages in staging file
stages_marks = st_data.Markers(staging_param.StagesIndex);
StageData = struct(...
    'Index', staging_param.StagesIndex, ...
    'Marks', {stages_marks}, ...
    'Data', st_data);

%% Data Processing
RemoveArtifacts(channel_file, chan_index, params.FilterParams.ArtifactParam);
FFTFiltering(channel_file, chan_index, params.FilterParams.FFTFilterParam);

%% Event Processing
channel_info = ChannelInfo(channel_file, chan_index, params.WTParam);

%% Find Slow Waves
sw_wave_ind = 1;
sw_data = SlowWaveEventDetection(params.WTParam, params.SlowWaveParam, StageData, channel_info, sw_wave_ind);

event_data{sw_wave_ind} = sw_data;
clear sw_data;

%% Find Spindle
sp_wave_ind = 2;
sp_data = SpindleEventDetection(params.WTParam, params.SpindleParam, StageData, channel_info, sp_wave_ind);

%append new wave to the sws data structure
event_data{sp_wave_ind} = sp_data;
clear sp_data;

%% Find Theta Burst
tb_wave_ind = 3;
tb_data = SpindleEventDetection(params.WTParam, params.ThetaBurstParam, StageData, channel_info, tb_wave_ind);

%append new wave to the sws data structure
event_data{tb_wave_ind} = tb_data;
clear tb_data;

%% Split Slow Waves by Transition Frequency
sw_high_tf_ind = 4;
sw_low_tf_ind = 5;
params.TFParam.ParentEvent = sw_wave_ind;
params.TFParam.ParentEventIndex = 1:length(event_data{params.TFParam.ParentEvent}.EventNumber);

[above_cutoff,below_cutoff] = SortSWTransitionFrequency(params.TFParam, event_data);

event_data{sw_high_tf_ind} = above_cutoff;
event_data{sw_low_tf_ind} = below_cutoff;

clear above_cutoff
clear below_cutoff

%% Match High TF SlowWave to Spindle
high_tf_sp_event_match_wave_ind = 6;
primary_wave_ind = sw_high_tf_ind;
secondary_wave_ind = sp_wave_ind;
high_tf_sp_wave_ind_to_match = [primary_wave_ind, secondary_wave_ind];
high_tf_sp_event_ind_to_match = cell(1, 2);
for w=1:2
    high_tf_sp_event_ind_to_match{w} = 1:length(event_data{high_tf_sp_wave_ind_to_match(w)}.EventNumber);
end
time_match_events.WaveIndex =  high_tf_sp_wave_ind_to_match;
time_match_events.EventIndex =  high_tf_sp_event_ind_to_match;
event_match_opts = struct(...
        'IndicesToMatch', high_tf_sp_wave_ind_to_match, ...
        'Primary', primary_wave_ind, ...
        'Secondary', secondary_wave_ind ...
    );

ref_wave = FindLongestEvent(high_tf_sp_wave_ind_to_match, event_data);
params.SWToSpindleEventMatchParam.StartTime = ref_wave.StartTime;
params.SWToSpindleEventMatchParam.EndTime = ref_wave.EndTime;
sr = mapChanData.SamplingRate(ref_wave.MapChanIndex,:);

[temp_event_match_data, ~] = MatchEvents(event_match_opts, time_match_events, params.SWToSpindleEventMatchParam, event_data, sr);

%append new wave to the sws data structure
event_data{high_tf_sp_event_match_wave_ind} = temp_event_match_data;
clear temp_event_match_data time_match_events;

%% Match Low TF SlowWave to Spindle
low_tf_sp_event_match_wave_ind = 7;
primary_wave_ind = sw_low_tf_ind;
secondary_wave_ind = sp_wave_ind;
low_tf_sp_wave_ind_to_match = [primary_wave_ind, secondary_wave_ind];
low_tf_sp_event_ind_to_match = cell(1, 2);
for w=1:2
    low_tf_sp_event_ind_to_match{w} = 1:length(event_data{low_tf_sp_wave_ind_to_match(w)}.EventNumber);
end
time_match_events.WaveIndex =  low_tf_sp_wave_ind_to_match;
time_match_events.EventIndex =  low_tf_sp_event_ind_to_match;
event_match_opts = struct(...
        'IndicesToMatch', low_tf_sp_wave_ind_to_match, ...
        'Primary', primary_wave_ind, ...
        'Secondary', secondary_wave_ind ...
    );

ref_wave = FindLongestEvent(low_tf_sp_wave_ind_to_match, event_data);
params.SWToSpindleEventMatchParam.StartTime = ref_wave.StartTime;
params.SWToSpindleEventMatchParam.EndTime = ref_wave.EndTime;
sr = mapChanData.SamplingRate(ref_wave.MapChanIndex,:);

[temp_event_match_data, ~] = MatchEvents(event_match_opts, time_match_events, params.SWToSpindleEventMatchParam, event_data, sr);

%append new wave to the sws data structure
event_data{low_tf_sp_event_match_wave_ind} = temp_event_match_data;
clear temp_event_match_data time_match_events;

%% Match High TF SlowWave to Theta Burst
high_tf_tb_event_match_wave_ind = 8;
primary_wave_ind = sw_high_tf_ind;
secondary_wave_ind = tb_wave_ind;
high_tf_tb_wave_ind_to_match = [primary_wave_ind, secondary_wave_ind];
high_tf_tb_event_ind_to_match = cell(1, 2);
for w=1:2
    high_tf_tb_event_ind_to_match{w} = 1:length(event_data{high_tf_tb_wave_ind_to_match(w)}.EventNumber);
end
time_match_events.WaveIndex =  high_tf_tb_wave_ind_to_match;
time_match_events.EventIndex =  high_tf_tb_event_ind_to_match;
event_match_opts = struct(...
        'IndicesToMatch', high_tf_tb_wave_ind_to_match, ...
        'Primary', primary_wave_ind, ...
        'Secondary', secondary_wave_ind ...
    );

ref_wave = FindLongestEvent(high_tf_tb_wave_ind_to_match, event_data);
params.SWToThetaBurstEventMatchParam.StartTime = ref_wave.StartTime;
params.SWToThetaBurstEventMatchParam.EndTime = ref_wave.EndTime;
sr = mapChanData.SamplingRate(ref_wave.MapChanIndex,:);

[temp_event_match_data, ~] = MatchEvents(event_match_opts, time_match_events, params.SWToThetaBurstEventMatchParam, event_data, sr);

%append new wave to the sws data structure
event_data{high_tf_tb_event_match_wave_ind} = temp_event_match_data;
clear temp_event_match_data time_match_events;

%% Match Low TF SlowWave to Theta Burst
low_tf_tb_event_match_wave_ind = 9;
primary_wave_ind = sw_low_tf_ind;
secondary_wave_ind = tb_wave_ind;
low_tf_tb_wave_ind_to_match = [primary_wave_ind, secondary_wave_ind];
low_tf_tb_event_ind_to_match = cell(1, 2);
for w=1:2
    low_tf_tb_event_ind_to_match{w} = 1:length(event_data{low_tf_tb_wave_ind_to_match(w)}.EventNumber);
end
time_match_events.WaveIndex =  low_tf_tb_wave_ind_to_match;
time_match_events.EventIndex =  low_tf_tb_event_ind_to_match;
event_match_opts = struct(...
        'IndicesToMatch', low_tf_tb_wave_ind_to_match, ...
        'Primary', primary_wave_ind, ...
        'Secondary', secondary_wave_ind ...
    );

ref_wave = FindLongestEvent(low_tf_tb_wave_ind_to_match, event_data);
params.SWToThetaBurstEventMatchParam.StartTime = ref_wave.StartTime;
params.SWToThetaBurstEventMatchParam.EndTime = ref_wave.EndTime;
sr = mapChanData.SamplingRate(ref_wave.MapChanIndex,:);

[temp_event_match_data, ~] = MatchEvents(event_match_opts, time_match_events, params.SWToThetaBurstEventMatchParam, event_data, sr);

%append new wave to the sws data structure
event_data{low_tf_tb_event_match_wave_ind} = temp_event_match_data;
clear temp_event_match_data time_match_events;

%% Create spectrogram for High TF-Spindle matched data
if ~isempty(event_data{high_tf_sp_event_match_wave_ind}.WaveIndex)
    save_dir = fullfile(params.SpectrogramOutputDir, 'HighTFSpindle/');

    temp_bandpass_data = BandPassEvent(params.BandpassParams, event_data, high_tf_sp_event_match_wave_ind, channel_file);
    sp_event_ind_for_sg = 1:length(temp_bandpass_data.EventNumber);
    
    %Create spectrogram
    temp_sg_data = CreateNewSpectrogram(sr, temp_bandpass_data, params.SpindleSpectrogramParam, sp_event_ind_for_sg);
    high_tf_sp_sg_data = NormalizeSpectrogramData(temp_sg_data, true);
    high_tf_sp_sg_data.SubjectId = edf_name;
    save_file = strcat(save_dir, edf_name, '_EventSpectrograms', num2str(params.SpindleSpectrogramParam.MinFrequency), 'to', num2str(params.SpindleSpectrogramParam.MaxFrequency), 'Hz', '.mat');
    save(save_file, '-struct', 'high_tf_sp_sg_data');
    clear temp_bandpass_data temp_sg_data;
else
    warning('No event matches found for High TF-Spindle')
end

%% Create spectrogram for Low TF-Spindle matched data
if ~isempty(event_data{low_tf_sp_event_match_wave_ind}.WaveIndex)
    save_dir = fullfile(params.SpectrogramOutputDir, 'LowTFSpindle/');

    temp_bandpass_data = BandPassEvent(params.BandpassParams, event_data, low_tf_sp_event_match_wave_ind, channel_file);
    sp_event_ind_for_sg = 1:length(temp_bandpass_data.EventNumber);
    
    %Create spectrogram
    temp_sg_data = CreateNewSpectrogram(sr, temp_bandpass_data, params.SpindleSpectrogramParam, sp_event_ind_for_sg);
    low_tf_sp_sg_data = NormalizeSpectrogramData(temp_sg_data, true);
    low_tf_sp_sg_data.SubjectId = edf_name;
    save_file = strcat(save_dir, edf_name, '_EventSpectrograms', num2str(params.SpindleSpectrogramParam.MinFrequency), 'to', num2str(params.SpindleSpectrogramParam.MaxFrequency), 'Hz', '.mat');
    save(save_file, '-struct', 'low_tf_sp_sg_data');
    clear temp_bandpass_data temp_sg_data;
else
    warning('No event matches found for Low TF-Spindle')
end

%% Create spectrogram for High TF-Theta Burst matched data
if ~isempty(event_data{high_tf_tb_event_match_wave_ind}.WaveIndex)
    save_dir = fullfile(params.SpectrogramOutputDir, 'HighTFThetaBurst/');

    temp_bandpass_data = BandPassEvent(params.BandpassParams, event_data, high_tf_tb_event_match_wave_ind, channel_file);
    tb_event_ind_for_sg = 1:length(temp_bandpass_data.EventNumber);
    
    %Create spectrogram
    temp_sg_data = CreateNewSpectrogram(sr, temp_bandpass_data, params.ThetaBurstSpectrogramParam, tb_event_ind_for_sg);
    high_tf_tb_sg_data = NormalizeSpectrogramData(temp_sg_data, true);
    high_tf_tb_sg_data.SubjectId = edf_name;
    save_file = strcat(save_dir, edf_name, '_EventSpectrograms', num2str(params.ThetaBurstSpectrogramParam.MinFrequency), 'to', num2str(params.ThetaBurstSpectrogramParam.MaxFrequency), 'Hz', '.mat');
    save(save_file, '-struct', 'high_tf_tb_sg_data');
    clear temp_bandpass_data temp_sg_data;
else
    warning('No event matches found for High TF-Theta Burst')
end

%% Create spectrogram for Low TF-Theta Burst matched data
if ~isempty(event_data{low_tf_tb_event_match_wave_ind}.WaveIndex)
    save_dir = fullfile(params.SpectrogramOutputDir, 'LowTFThetaBurst/');

    temp_bandpass_data = BandPassEvent(params.BandpassParams, event_data, low_tf_tb_event_match_wave_ind, channel_file);
    tb_event_ind_for_sg = 1:length(temp_bandpass_data.EventNumber);
    
    %Create spectrogram
    temp_sg_data = CreateNewSpectrogram(sr, temp_bandpass_data, params.ThetaBurstSpectrogramParam, tb_event_ind_for_sg);
    low_tf_tb_sg_data = NormalizeSpectrogramData(temp_sg_data, true);
    low_tf_tb_sg_data.SubjectId = edf_name;
    save_file = strcat(save_dir, edf_name, '_EventSpectrograms', num2str(params.ThetaBurstSpectrogramParam.MinFrequency), 'to', num2str(params.ThetaBurstSpectrogramParam.MaxFrequency), 'Hz', '.mat');
    save(save_file, '-struct', 'low_tf_tb_sg_data');
    clear temp_bandpass_data temp_sg_data;
else
    warning('No event matches found for Low TF-Theta Burst')
end
%Populate CSV file data
csv_data = cell(1, length(event_data)+1);
csv_data{1} = string(edf_name);
for s = 1:length(event_data)
    csv_data{s+1} = size(event_data{s}.TimeSeries,2);
end

%% Write event data to csv file
input_table = readtable(params.CSVSaveFileName);
new_csv_data = table2cell(input_table);
new_csv_data(end+1, :) = csv_data;
new_table = cell2table(new_csv_data);
new_table.Properties.VariableNames = input_table.Properties.VariableNames;

% Write to CSV file
writetable(new_table, params.CSVSaveFileName)
close all;
clear all;
clc;

swswaitbar ( '**disable**' );

edf_filename_fullpath = '';
staging_filename = '';

input_dir = '';
output_dir = strcat(input_dir, '/../output');
edf_folder_string = 'A. edfs';
stage_folder_string='B. staging';

filecount = 0;
params = ManuscriptParams();
params.OutputDir = output_dir;
params.CSVSaveFileName = strcat(output_dir, params.CSVSaveFileName);

params.SpectrogramOutputDir = fullfile(output_dir, 'SpectrogramData');
if ~exist(params.SpectrogramOutputDir, 'dir')
    mkdir(params.SpectrogramOutputDir)
end

%% Spectrogram directory setup
high_tf_sp_folder_label = 'HighTFSpindle';
high_tf_sp_ouput_folder = fullfile(params.SpectrogramOutputDir, high_tf_sp_folder_label);
if ~exist(high_tf_sp_ouput_folder, 'dir')
    mkdir(high_tf_sp_ouput_folder)
end

low_tf_sp_folder_label = 'LowTFSpindle';
low_tf_sp_ouput_folder = fullfile(params.SpectrogramOutputDir, low_tf_sp_folder_label);
if ~exist(low_tf_sp_ouput_folder, 'dir')
    mkdir(low_tf_sp_ouput_folder)
end

high_tf_tb_folder_label = 'HighTFThetaBurst';
high_tf_tb_ouput_folder = fullfile(params.SpectrogramOutputDir, high_tf_tb_folder_label);
if ~exist(high_tf_tb_ouput_folder, 'dir')
    mkdir(high_tf_tb_ouput_folder)
end

low_tf_tb_folder_label = 'LowTFThetaBurst';
low_tf_tb_ouput_folder = fullfile(params.SpectrogramOutputDir, low_tf_tb_folder_label);
if ~exist(low_tf_tb_ouput_folder, 'dir')
    mkdir(low_tf_tb_ouput_folder)
end

%% Set up CSV File
csv_struct.Columns = { ...
    'SubjectID', 'SlowWave', 'Spindle', 'ThetaBurst', ...
    'HighTFSlowWave', 'LowTFSlowWave', ...
    'HighTFSlowWaveMatchToSpindle', 'LowTFSlowWaveMatchToSpindle', ...
    'HighTFSlowWaveMatchToThetaBurst', 'LowTFSlowWaveMatchToThetaBurst'};
csv_struct.Columns = matlab.lang.makeValidName(csv_struct.Columns);
csv_table = array2table(zeros(0,length(csv_struct.Columns)));
csv_table.Properties.VariableNames = csv_struct.Columns;
writetable(csv_table, params.CSVSaveFileName);

%% Move through input directory
datadirs = dir(input_dir);
dircell = struct2cell(datadirs)';   
folders_to_batch = dircell(3:end,1);
for d = 1:length(folders_to_batch)
    subject_folder = fullfile(input_dir,folders_to_batch{d});
    if ~isfolder(subject_folder)
        continue
    end
    subfolder_paths = GetFileSubfolderPath(input_dir, folders_to_batch{d}, edf_folder_string);
    if ~iscell(subfolder_paths)
        subfolder_paths = {subfolder_paths};
    end
    for s = 1:length(subfolder_paths)
        this_edf_folder = fullfile(input_dir, subfolder_paths{s}, edf_folder_string);
        this_stage_folder = fullfile(input_dir, subfolder_paths{s}, stage_folder_string);

        params.ChannelOutputDir = fullfile(output_dir, 'ChannelFiles/', subfolder_paths{s});
        if ~exist(params.ChannelOutputDir, 'dir')
            mkdir(params.ChannelOutputDir)
        end

        %Get edf Files
        edf_dir = dir(this_edf_folder);
        dircell = struct2cell(edf_dir)';
        edf_files_to_batch = dircell(3:end,1);

        %Get staging files in directory
        stage_dir = dir(this_stage_folder);
        stage_dircell = struct2cell(stage_dir)';   
        staging_filenames = stage_dircell(3:end,1);

        %Loop over files in directory
        filecount = 1;
        for f = 1:length(edf_files_to_batch)
            if strcmpi(edf_files_to_batch{f},".") || strcmpi(edf_files_to_batch{f}, "..") || contains(edf_files_to_batch{f}, ".DS_Store")
                continue
            end
            this_edf_file = fullfile(this_edf_folder,edf_files_to_batch{f});
            [~,subjectid_filename,~] = fileparts(this_edf_file);
    
            %Find staging file in directory
            stage_filename = strcat(subjectid_filename, '_EpochReport.xlsx');
            stage_file_index = find(strcmpi(staging_filenames, stage_filename));
            if isempty(stage_file_index)
                warning(strcat(stage_filename, ' stage file not found in specified directory. Skipping file'));
                continue
            end
            this_stage_file = fullfile(this_stage_folder,staging_filenames{stage_file_index});

            params.EdfFile = this_edf_file;
            params.StageFile = this_stage_file;
            try
                RunManuscriptStepsOnFile(params);
            catch ME
                warning_str = 'An error occured with %s:\n%s';
                warning(warning_str, this_edf_file, getReport(ME, 'extended', 'hyperlinks', 'on' ));
                continue
            end
        end
    end 
end

GetSpectrogramRoundShapesInDir(params.SpectrogramOutputDir, high_tf_sp_folder_label, params.SpindlePixelBoxParam, params.SpindleCircularROIParam, params.DetectRoundShapeParam);
GetSpectrogramRoundShapesInDir(params.SpectrogramOutputDir, low_tf_sp_folder_label, params.SpindlePixelBoxParam, params.SpindleCircularROIParam, params.DetectRoundShapeParam);
GetSpectrogramRoundShapesInDir(params.SpectrogramOutputDir, high_tf_tb_folder_label, params.ThetaBurstPixelBoxParam, params.ThetaBurstCircularROIParam, params.DetectRoundShapeParam);
GetSpectrogramRoundShapesInDir(params.SpectrogramOutputDir, low_tf_tb_folder_label, params.ThetaBurstPixelBoxParam, params.ThetaBurstCircularROIParam, params.DetectRoundShapeParam);

input_table = readtable(params.CSVSaveFileName);
subject_ids = input_table.SubjectID;
roi_csv_filename = strcat('ROI_Intensity_Values');
roi_csv_file = fullfile(params.OutputDir, strcat(roi_csv_filename, '.csv'));
roi_table = table(subject_ids, 'VariableNames', {'SubjectID'});
writetable(roi_table,roi_csv_file);

GetSpectrogramROIsInDir(params.SpectrogramOutputDir, high_tf_sp_folder_label, params.SpindlePixelBoxParam, roi_csv_file);
GetSpectrogramROIsInDir(params.SpectrogramOutputDir, low_tf_sp_folder_label, params.SpindlePixelBoxParam, roi_csv_file);
GetSpectrogramROIsInDir(params.SpectrogramOutputDir, high_tf_tb_folder_label, params.ThetaBurstPixelBoxParam, roi_csv_file);
GetSpectrogramROIsInDir(params.SpectrogramOutputDir, low_tf_tb_folder_label, params.ThetaBurstPixelBoxParam, roi_csv_file);

clear all;

function GetSpectrogramRoundShapesInDir(sg_folder, folder_label, pixel_box_param, circle_roi_param, detect_round_shape_param)
sg_input_dir = fullfile(sg_folder, folder_label);
csv_file = fullfile(sg_folder, '/../', strcat(folder_label, '_roi_counts.csv'));
sg_dir = dir(sg_input_dir);
dircell = struct2cell(sg_dir)';
sg_files = dircell(3:end,1);

num_sg_files = length(sg_files);
roi_circle_counts = cell(num_sg_files, 4);
for i=1:num_sg_files
    sg_data = load(fullfile(sg_input_dir, sg_files{i}));
    [~, round_shape_output] = DetectRoundShapesInSpectrogram(sg_data, pixel_box_param, circle_roi_param, detect_round_shape_param);
    roi_circle_counts(i, :, :, :) = {sg_data.SubjectId, 0, 0, 0};
    if isempty(round_shape_output)
        warning('No circles found in ROI(s) for file: %s', sg_files{i})
        continue;
    end

    roi_circle_counts{i,2} = length(round_shape_output.CircleDataInd{2});
    roi_circle_counts{i,3} = length(round_shape_output.CircleDataInd{1}) ...
        - length(round_shape_output.CircleDataInd{2});
    roi_circle_counts{i,4} = length(round_shape_output.CircleDataInd{1});
end

roi_var_names = {'SubjectID', 'InnerCircle', 'OuterCircle', 'TotalInROI'};

no_results = cellfun(@isempty,roi_circle_counts);
no_results = all(no_results);
if(no_results)
    warning('Could not detect circle(s) within the ROI(s) specified for selected file(s). Try adjusting criteria.');
else
    round_shapes_table = cell2table(roi_circle_counts, 'VariableNames',roi_var_names);
    writetable(round_shapes_table,csv_file);
end
end

function GetSpectrogramROIsInDir(sg_folder, folder_label, pixelbox_params, csv_file)
sg_input_dir = fullfile(sg_folder, folder_label);

sg_dir = dir(sg_input_dir);
dircell = struct2cell(sg_dir)';
sg_files = dircell(3:end,1);
for f = 1:length(sg_files)
    sg_files{f} = fullfile(sg_input_dir, sg_files{f});
end

sg_data = AverageSpectrograms(sg_files);
roi_values = GetSpectrogramROIValues(pixelbox_params, sg_data);

input_table = readtable(csv_file, 'Delimiter', ',');
new_csv_data = table2cell(input_table);
new_csv_data(:, end+1) = num2cell(roi_values)';
new_table = cell2table(new_csv_data);
var_names = input_table.Properties.VariableNames;
var_names{end+1} = strcat(folder_label, '_ROIValue');
new_table.Properties.VariableNames = var_names;

% Write to CSV file
writetable(new_table, csv_file)
end
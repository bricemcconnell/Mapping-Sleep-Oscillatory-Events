function PlotWaveletSpectrogram(fig, sg_data, mapcolor)
fig_name = sprintf('Wavelet (I) Spectrogram: %s [%d]', ...
    sg_data.Label, sg_data.NumberOfEventGroups);
fig.Name = fig_name;
ax = axes('Parent', fig);
imagesc(sg_data.Time,sg_data.Frequency,sg_data.Spectrogram);
axis(ax, 'xy')
%Fix for previous iterations where event number already included length
%rather than being a vector of event numbers
num_events = sg_data.EventNumber;
if length(sg_data.EventNumber) > 1
    num_events = length(sg_data.EventNumber);
end
title(sprintf('Number of Events: %d', num_events));
xlabel(ax, 'seconds');
ylabel(ax, 'Frequency, [Hz]');
colorbar();
colormap(mapcolor);
end
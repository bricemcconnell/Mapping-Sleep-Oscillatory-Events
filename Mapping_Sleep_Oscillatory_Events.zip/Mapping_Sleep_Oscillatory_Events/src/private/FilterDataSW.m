function data = FilterDataSW(data, fs, min_freq, max_freq, filter_order)

half_sr = .5*fs;%half sampling rate

%make filter
[B, A] = butter(filter_order,[min_freq, max_freq]/half_sr);%slow wave filter


%detrend data
data = detrend(data);
%apply filter
data = filtfilt(B,A,data);
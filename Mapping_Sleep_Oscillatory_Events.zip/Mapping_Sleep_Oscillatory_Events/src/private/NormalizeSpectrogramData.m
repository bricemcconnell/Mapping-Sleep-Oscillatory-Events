function sg_data = NormalizeSpectrogramData(og_sg_data, to_average)
baseline_win = og_sg_data.BaseLine;
win = og_sg_data.Window;

%Get final spectrogram data
if (to_average)
    spectrogram = mean(og_sg_data.Spectrogram,3);
    event_num = length(og_sg_data.EventIndex);
    sg_norm = spectrogram(:,win)./baseline_win;%normalize by the base line
    %variance
    vr = var(spectrogram,1,3);
    vr = vr(:,win);
else
    num_events = size(og_sg_data.Spectrogram,3);
    event_num = 1:num_events;

    sg_norm = zeros(size(baseline_win,1), length(win), num_events);
    vr = zeros(size(sg_norm));
    for e = 1:num_events
        event_sg = og_sg_data.Spectrogram(:,:,e);
        sg_norm(:,:,e) = event_sg(:,win)./baseline_win;%normalize by the base line
        
        %variance
        vr_temp = [];
        vr_temp = var(event_sg,1,3);
        vr(:,:,e) = vr_temp(:,win);
    end
end

sg_data = struct(...
    'Label', og_sg_data.Label, ...
    'EventNumber', event_num, ...
    'NumberOfEventGroups', 1, ...
    'Spectrogram', sg_norm, ...
    'Variance', vr, ...
    'BaseLine', og_sg_data.BaseLine, ...
    'Frequency', og_sg_data.Frequency,...
    'Time', og_sg_data.Time);
end
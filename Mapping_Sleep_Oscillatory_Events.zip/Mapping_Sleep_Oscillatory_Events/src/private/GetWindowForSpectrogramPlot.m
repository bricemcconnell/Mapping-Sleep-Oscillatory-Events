function [win, baseline_win, t] = GetWindowForSpectrogramPlot(baseline, event_ind, fs, sg_param)
%Convert time to index
first_sample = event_ind + round(sg_param.WindowStart*fs);
if first_sample == 0
    first_sample = 1;
end
last_sample = first_sample + round(sg_param.WindowWidth*fs);
win = first_sample : last_sample;
ns = length(win);%number of samples

avg_baseline = mean(baseline,3);
if win(end)>size(avg_baseline,2)
    win = win(win<=size(avg_baseline,2));
end
baseline_win = repmat(mean(avg_baseline(:,win),2),1,ns);

%get time vector for the image
t = linspace(sg_param.WindowStart, sg_param.WindowStart+sg_param.WindowWidth, ns);
end
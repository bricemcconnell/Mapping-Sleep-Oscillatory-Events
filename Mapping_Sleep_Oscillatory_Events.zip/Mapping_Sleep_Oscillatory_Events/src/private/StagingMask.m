function [label, st_mask] = StagingMask(label, StageData)
    st_data_run = StageData.Data.AdjStages;
    st_mask = zeros(size(st_data_run));
    %prep label
    label = cat(2,label,' Stage(s):');
    for ss = 1:length(StageData.Index)
        s_i = StageData.Index(ss);
        for s = 1:length(StageData.Marks{ss})
            if iscell(StageData.Marks{ss})
                s_m = StageData.Marks{ss}{s};
            else
                s_m = StageData.Marks{ss};
            end
            st_mask = st_mask+(st_data_run==s_m);
        end
        %append to label
        st_lbl = sprintf(' %s',StageData.Data.Labels(s_i));
        label = cat(2,label,st_lbl);
    end
return
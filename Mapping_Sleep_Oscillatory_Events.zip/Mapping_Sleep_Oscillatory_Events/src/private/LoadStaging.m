function st_data = LoadStaging(staging_file, full_time, param, sr)

opts = detectImportOptions(staging_file);
if length(opts.VariableTypes) > 3
    opts.SelectedVariableNames = opts.SelectedVariableNames(1:3);
    opts.VariableNames = opts.VariableNames(1:3);
    opts.VariableOptions = opts.VariableOptions(1:3);
    opts.VariableTypes = opts.VariableTypes(1:3);
end
opts = setvartype(opts, {'double', 'string', 'datetime'});
opts.VariableNames = {'Entry', 'Stage', 'Time'};
stage_table=readtable(staging_file, opts);
stage_table.Time.Format = 'hh:mm:ss';

[~,filename,~] = fileparts(staging_file);

epoch_length = param.SecondsPerStage;

%compute the vectors
st = stage_table.Stage;
stages_t = linspace(1,full_time,length(st))./60./60;
st_data_ratio = sr*epoch_length;

adj_st = strings(1, length(st)*st_data_ratio);
for s = 1:length(st)
    adj_st((s-1)*st_data_ratio+1:s*st_data_ratio) = st(s);
end

% must be listed in ascending numerical order
markers = {param.N1Marker; param.N2Marker; param.N3Marker; ...
    param.LightsMarker; param.MuscleMarker; param.REMMarker; param.WakeMarker};
labels = {param.N1Label; param.N2Label; param.N3Label; ...
    param.LightsLabel; param.MuscleLabel; param.REMLabel; param.WakeLabel};

%data structure
st_data = struct(...
    'FileName', filename, ...
    'Type', 'WashU', ...
    'EpochLength', epoch_length, ...
    'SamplingRate', param.DataSamplingRate, ...
    'Markers', {markers}, ...
    'Labels', string(labels)', ...
    'StDataRatio', st_data_ratio, ...
    'OriginalTimeTicks', stages_t, ...
    'OriginalStages', st, ...
    'AdjStages', adj_st);
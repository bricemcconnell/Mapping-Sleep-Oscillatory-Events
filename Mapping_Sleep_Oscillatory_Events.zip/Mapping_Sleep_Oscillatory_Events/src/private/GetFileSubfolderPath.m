function subfolder_path = GetFileSubfolderPath(og_dir, current_dir, folder_string)
if strcmpi(current_dir, folder_string)
    subfolder_path = current_dir;
    return
end
subfolder_path = {};
datadirs = dir(fullfile(og_dir, current_dir));
dircell = struct2cell(datadirs)';   
current_dir_files = dircell(3:end,1);
remove_ind = contains(current_dir_files, '.DS_Store');
current_dir_files = current_dir_files(~remove_ind);
for d = 1:length(current_dir_files)
    this_subdir = fullfile(current_dir, current_dir_files{d});
    this_dir = fullfile(og_dir, this_subdir);
    if strcmpi(current_dir_files{d}, folder_string)
        subfolder_path = current_dir;
        return
    elseif isfolder(this_dir)
        subfolder_path{end+1} = GetFileSubfolderPath(og_dir, this_subdir, folder_string);
    else
        subfolder_path = [];
    end
end

end
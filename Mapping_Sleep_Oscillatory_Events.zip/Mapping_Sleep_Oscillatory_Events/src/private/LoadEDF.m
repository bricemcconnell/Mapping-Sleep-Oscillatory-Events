function edf = LoadEDF(file, rescale_opt)
%WIP - load edf file

%load data
[data, hdr] = edfread(file);

%initalize duration
dur = hdr.DurationSeconds*hdr.NumberOfRecords;
dur_str = sprintf('%s', duration(seconds(dur),'format','hh:mm:ss'));

%option to rescale edf
if ~any(contains(hdr.PhysicalDimension,'uV'))
    if isempty(rescale_opt)
        quest = 'Some of file does not appear to be in uV. Rescale?';
        name = 'Rescale Option';
        answer = questdlg(quest,name,'Yes','No','Yes'); 
        %user canceled
        if isempty(answer)
            return
        end
        verbose = true;
    else
        answer = rescale_opt;
        verbose = false;
    end
    if strcmpi('yes', answer)
        [data, hdr] = RescaleEDFData(data,hdr, verbose);
    end
end

% channel list
chanList = string(hdr.Label);

for cL=1:length(chanList)
    while contains(chanList(cL),'  ')
        chanList(cL) = replace(chanList(cL),'  ',' ');
    end
end



%data is cell array - must put extra {} in struct
edf = struct(...
    'FileName', file, ...
    'Header', hdr, ...
    'Duration', dur_str, ...
    'ChannelList', chanList, ...
    'Data', {data});


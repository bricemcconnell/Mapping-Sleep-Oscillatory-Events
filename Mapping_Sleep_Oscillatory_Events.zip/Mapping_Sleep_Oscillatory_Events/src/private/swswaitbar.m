function h = swswaitbar ( varargin )
  % preallocate output
  h = [];
  % use an internal persistent variable
  persistent active
  % by default set to true
  if isempty ( active ); active = true; end
  % Check to see if its a control call
  if nargin == 1 && ischar ( varargin{1} )
    % is it a call to disable it?
    if strcmp ( varargin{1}, '**disable**' )
      active = false;
    else 
      active = true;
    end
    return
  end
  if active 
    h = waitbar ( varargin{:} );
  end
end
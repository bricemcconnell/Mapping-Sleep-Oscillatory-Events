function spindle_features = FindSpindleEnvelope(sp_param, filt_data, event_markers)

%time poitn indexes and time vector
ind = 1:length(filt_data);

%get spindle envelope
spindle_env = envelope(filt_data);

spindle_env(event_markers.StageMask == 0) = 0;

%get spindle events
spindle_env(spindle_env > sp_param.DetectThreshold) = 0;%remove events with too large amplitude
spindle_env_nz = nonzeros(spindle_env)'; %remove zeros to get proper mean and std

sort_rms = sort(spindle_env_nz);%ascending order
sort_rms(spindle_env_nz>(mean(spindle_env_nz)+sp_param.DiscardNStd*std(spindle_env_nz))) = 0;
sort_rms = nonzeros(sort_rms)';

na = floor(sp_param.UpperPerCent*length(sort_rms));%Remove percent below upper percent
spindles_th = sort_rms(na);

%time point above threshold
above_th = spindle_env > spindles_th;
spindle_env(~above_th) = 0;%zero out point below threshold
cross_th = diff(above_th);

cross_up = ind(cross_th > 0);%coming above threshold
cross_dn = ind(cross_th < 0);%coming below threshold
if cross_up(1) > cross_dn(1)
    cross_dn(1) = [];
end
if cross_up(end) > cross_dn(end)
    cross_up(end) = [];
end

%now length of ups and downs should be the same
delta = cross_dn - cross_up;
sn = length(delta);%number of potential spindles
spindle_true = true(1,sn);
spindle_ind = zeros(2,sn);%first and last spindle indexes
max_env_ind = zeros(1,sn);%max envelope values
max_env_val = zeros(1,sn);
max_ind = zeros(1,sn);%max spindle values
max_val = zeros(1,sn);
min_ind = zeros(1,sn);%min spindle values
min_val = zeros(1,sn);

    
for ii=1:sn    
    %remove if too close to the ends
    if cross_up(ii) < event_markers.PreEventDur || ...
            cross_dn(ii) > length(filt_data) - event_markers.PostEventDur
        spindle_true(ii) = false;
    %remove if less than nyquist and > 3*event_markers.SampleRate
    elseif delta(ii) < .5*event_markers.SampleRate || delta(ii) > 3*event_markers.SampleRate
        spindle_env(cross_up(ii):cross_dn(ii)) = 0;
        spindle_true(ii) = false;    
    else
        %get max envelope value
        [max_env_val(ii), max_env_ind(ii)] = max(spindle_env(cross_up(ii):cross_dn(ii)));
        
        %get max,min spindle values for locking
        [max_val(ii), max_ind(ii)] = max(filt_data(cross_up(ii):cross_dn(ii)));
        [min_val(ii), min_ind(ii)] = min(filt_data(cross_up(ii):cross_dn(ii)));
        
        %adjust index
        max_env_ind(ii) = cross_up(ii) + max_env_ind(ii) - 1;
        max_ind(ii) = cross_up(ii) + max_ind(ii) - 1;
        min_ind(ii) = cross_up(ii) + min_ind(ii) - 1;
        spindle_ind(:,ii) = [cross_up(ii), cross_dn(ii)];
    end
end

min_ind = min_ind(spindle_true);
min_val = min_val(spindle_true);
max_ind = max_ind(spindle_true);
max_val = max_val(spindle_true);
max_env_ind = max_env_ind(spindle_true);
max_env_val = max_env_val(spindle_true);
spindle_ind = spindle_ind(:,spindle_true);%first and last indexes for event

%data structure
spindle_features = struct(...
    'MaxEnvelopeIndex', max_env_ind, ...
    'MaxEnvelopeValue', max_env_val, ...
    'MaxIndex', max_ind, ...
    'MaxValue', max_val, ...
    'MinIndex', min_ind, ...
    'MinValue', min_val, ...
    'SpindleIndex', spindle_ind, ...
    'FilteredData', filt_data, ...
    'SpindleEnvelope', spindle_env);
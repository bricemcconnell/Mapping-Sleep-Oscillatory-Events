function [common_ind, output] = DetectRoundShapesInSpectrogram(sg_data, roi_box_param, roi_circle_param, detect_param)
    format long;
    %Initialize cells and vectors
    adj_centroid = [];
    adj_boundary = [];
    current_keep_ind = 1;
    og_ind_kept = cell(1, roi_circle_param.NumCircles);
    og_ind_kept_tracker = ones(1, roi_circle_param.NumCircles);
    precision_ind = cell(1, roi_circle_param.NumCircles);
    precision_ind_tracker = ones(1, roi_circle_param.NumCircles);
    
    common_ind = [];

    %Setup static data used
    sg = sg_data.Spectrogram;
    num_events = size(sg,3);
    sg_time = [sg_data.Time(1),sg_data.Time(end)];
    sg_freq = [sg_data.Frequency(1),sg_data.Frequency(end)];
    time_radius_adj = 16/3;

    %Find averaged sg data centroid and boundary
    if strcmpi(detect_param.AutoDetect, 'yes')
        avg_sg = mean(sg, 3);
        [avg_circle_data, time_freq_data] = FindRoundShapesFromSpectrogramData(avg_sg, sg_time, sg_freq, detect_param);
        if ~isempty(avg_circle_data)
            %Check if avg centroid is in ROI
            for c = 1:length(avg_circle_data.CentroidData)
                centroid = avg_circle_data.CentroidData{c};
                avg_centroid_time = time_freq_data.PixelTimeArray(1)+centroid(1)*time_freq_data.PixelTimeRatio;
                avg_centroid_freq = time_freq_data.PixelFreqArray(1)-centroid(2)*time_freq_data.PixelFreqRatio;

                isFreqInROI = find(avg_centroid_freq >= roi_box_param.StartFrequency & avg_centroid_freq <= roi_box_param.EndFrequency, 1);
                isTimeInROI = find(avg_centroid_time >= roi_box_param.StartTime & avg_centroid_time <= roi_box_param.EndTime, 1);
                if isempty(isFreqInROI) || isempty(isTimeInROI)
                    continue
                end
                roi_circle_param.CenterFrequency = time_freq_data.PixelFreqArray(1)-centroid(2)*time_freq_data.PixelFreqRatio;
                roi_circle_param.CenterTime = time_freq_data.PixelTimeArray(1)+centroid(1)*time_freq_data.PixelTimeRatio;

            end
        end
    end
    wb = swswaitbar(0,'Please wait...', 'Name','Finding Round Shapes in Spectrograms');
    for e = 1:num_events
        [circle_data, time_freq_data] = FindRoundShapesFromSpectrogramData(sg(:,:,e), sg_time, sg_freq, detect_param);
        if isempty(circle_data)
            continue
        end
        % loop over the boundaries
        for index = 1:length(circle_data.BoundaryData)
            boundary = circle_data.BoundaryData{index};

            % Convert boundary
            temp_boundary = boundary;
            temp_boundary(:,2) = time_freq_data.PixelTimeArray(boundary(:,2));
            temp_boundary(:,1) = time_freq_data.PixelFreqArray(boundary(:,1));

            % Convert centroids
            centroid = circle_data.CentroidData{index};
            temp_centroid_time = time_freq_data.PixelTimeArray(1)+centroid(1)*time_freq_data.PixelTimeRatio;
            temp_centroid_freq = time_freq_data.PixelFreqArray(1)-centroid(2)*time_freq_data.PixelFreqRatio;
          
            % Get detection criteria
            if strcmpi(detect_param.PrecisionMethod, 'boundary')
                time_comparator = temp_boundary(:,2);
                freq_comparator = temp_boundary(:,1);
            else
                time_comparator = temp_centroid_time;
                freq_comparator = temp_centroid_freq;
            end

            roi_center = [roi_circle_param.CenterTime , roi_circle_param.CenterFrequency];
            %Only find first match because only care that part
            %of shape is within ROI
            isShapeInROI = zeros(1, roi_circle_param.NumCircles);
            for c = 1:roi_circle_param.NumCircles
                roi_radius = roi_circle_param.CircleRadii{c};
                isFound = find((time_comparator-roi_center(1)).^2./((roi_radius/time_radius_adj)^2) + (freq_comparator-roi_center(end)).^2./(roi_radius.^2) < 1, 1);
                isShapeInROI(c) = ~isempty(isFound);
                if isShapeInROI(c)==0
                    break
                end

                og_ind_kept{c}(og_ind_kept_tracker(c)) = e;
                og_ind_kept_tracker(c) = og_ind_kept_tracker(c) + 1;
                precision_ind{c}(precision_ind_tracker(c)) = current_keep_ind;
                precision_ind_tracker(c) = precision_ind_tracker(c) + 1;
            end
            if ~any(isShapeInROI)
                continue
            end
            adj_boundary{current_keep_ind} = temp_boundary;
            
            % Convert pixels to time & frequency
            adj_centroid{current_keep_ind}(1) = temp_centroid_time;
            adj_centroid{current_keep_ind}(2) = temp_centroid_freq;
            current_keep_ind = current_keep_ind+1;

        end
        swswaitbar(e/num_events, wb);
    end
    close(wb);

    if isempty(adj_boundary) || isempty(adj_centroid)
        output = [];
        return;
    end

    this_roi_boundary = adj_boundary;
    this_roi_boundary = this_roi_boundary(~cellfun('isempty',this_roi_boundary));
    this_roi_centroid = adj_centroid;
    this_roi_centroid = this_roi_centroid(~cellfun('isempty',this_roi_centroid));
    output = struct(...
        'Boundaries', {this_roi_boundary}, ...
        'Centroids', {this_roi_centroid}, ...
        'OriginalEventInd', {og_ind_kept}, ...
        'CircleDataInd', {precision_ind}, ...
        'NumCircles', roi_circle_param.NumCircles);
end
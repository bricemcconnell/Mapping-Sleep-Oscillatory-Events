function grouped_events = GroupSpindleEvents(sp_param, sp_features, event_markers, start_time_offset)
sn = size(sp_features.SpindleIndex,2);

%figure out spindle number in the train
events_before = zeros(1, sn);
for cp=2:sn
    inter_spind_gap = sp_features.SpindleIndex(1,cp)-sp_features.SpindleIndex(2,cp-1);
    inter_spind_gap = inter_spind_gap/event_markers.SampleRate;%seconds
    if inter_spind_gap < sp_param.MaxNegHalfWave
        events_before(cp) = events_before(cp-1) + 1;
    end
end

events_after = zeros(1, sn);
for cp=sn:-1:2
    inter_spind_gap = sp_features.SpindleIndex(1,cp)-sp_features.SpindleIndex(2,cp-1);
    inter_spind_gap = inter_spind_gap/event_markers.SampleRate;%seconds
    if inter_spind_gap < sp_param.MaxNegHalfWave
        events_after(cp-1) = events_after(cp) + 1;
    end
end

%truncate number of events before or after
before_after = 9;
events_after(events_after>before_after) = before_after;
events_before(events_before>before_after) = before_after;

%now we can put both in one index
event_number = 10*events_before + events_after;

%event indexes
event_ind = -event_markers.PreEventDur:event_markers.PostEventDur;
event_length = length(event_ind);

event_center_marker_opts = [sp_features.SpindleIndex(1,:); sp_features.MaxEnvelopeIndex; sp_features.SpindleIndex(2,:); sp_features.MinIndex; sp_features.MaxIndex];
event_center_marker = event_center_marker_opts(sp_param.EventCenterMarkerI, :);

ts_max = zeros(event_length, sn); %spindle timeseries centered on max
ts_min = zeros(event_length, sn); %spindle timeseries centered on min
ts_env = zeros(event_length, sn); %spindle envelope centered timeseries
env_ts = zeros(event_length, sn); %envelope timeseries
ts = zeros(event_length, sn); %timeseries centered on selected event marker
wave_time = zeros(event_length,sn);
for ii=1:sn
    iii = sp_features.MaxEnvelopeIndex(ii)+event_ind; %centered 5s on spind
    jj = sp_features.MaxIndex(ii)+event_ind; %centered on max spind value
    kk = sp_features.MinIndex(ii)+event_ind;
    cc = event_center_marker(ii)+event_ind; %centered on selected event marker

    %time series
    ts_env(:,ii) = sp_features.FilteredData(iii);
    ts_max(:,ii) = sp_features.FilteredData(jj);
    ts_min(:,ii) = sp_features.FilteredData(kk);
    env_ts(:,ii) = sp_features.SpindleEnvelope(iii);
    
    ts(:,ii) = sp_features.FilteredData(cc);

    wave_time(:,ii) = cc;
end

%get data chunks just before selected waves:
baselinedur = event_length;%same number of samples as main wave
base_ind = -baselinedur:-1;

%sort
first_sample = sort(wave_time(1,:));
last_sample = [1 sort(wave_time(end,:))];
baseline = zeros(baselinedur, sn);
base_time = zeros(baselinedur, sn);
keep = false(1,sn);

for ii=1:sn
    if first_sample(ii)-last_sample(ii)>baselinedur
        base_time(:,ii) = first_sample(ii)+base_ind;
        baseline(:,ii)=sp_features.FilteredData(base_time(:,ii));
        if events_before(ii)==0
            keep(ii) = true;
        end
    end
end

%keep selected only
baseline = baseline(:,keep);
base_time = base_time(:,keep);

%adjust indexes for start time
max_env_ind_adj = zeros(size(sp_features.MaxEnvelopeIndex));
spindle_ind_adj = zeros(size(sp_features.SpindleIndex));
base_time_adj = zeros(size(base_time));
wave_time_adj = zeros(size(wave_time));
max_env_ind_adj(find(sp_features.MaxEnvelopeIndex)) = sp_features.MaxEnvelopeIndex(find(sp_features.MaxEnvelopeIndex))+start_time_offset;
spindle_ind_adj(find(sp_features.SpindleIndex)) = sp_features.SpindleIndex(find(sp_features.SpindleIndex))+start_time_offset;
base_time_adj(find(base_time)) = base_time(find(base_time))+start_time_offset;
wave_time_adj(find(wave_time)) = wave_time(find(wave_time))+start_time_offset;
    
%data structure
grouped_events = struct(...
    'TimeSeries', ts, ...
    'EnvelopeSeries', env_ts, ...
    'MaxEnvelopeIndex', max_env_ind_adj, ...
    'MaxEnvelopeValue', sp_features.MaxEnvelopeValue, ...
    'MinIndex', sp_features.MinIndex, ...
    'MaxIndex', sp_features.MaxIndex, ...
    'SpindleIndex', spindle_ind_adj, ...
    'EventNumber', event_number, ...
    'WaveTime', wave_time_adj, ...
    'BaseTime', base_time_adj, ...
    'BaseLine', baseline);
end
function RemoveArtifacts(chan_file,chan, param)
Channels = matfile(chan_file,'Writable',true);

%remove artifact and process data
            
%get channel data
sr = Channels.SamplingRate(chan,:);
raw_data = Channels.RawRun(chan,:);
dtrn = detrend(raw_data);

%remove artifact
data_artifact_rmvd = zeros(size(raw_data));
current_section = [];

%step size
s = sr*param.ArtifactWidth;

%swswaitbar
wb = swswaitbar(0,'Please wait...', 'Name', 'Artifact Reduction in Progress');

for ii = 1:s:(length(raw_data)-s)
    if range(dtrn(ii:ii+s-1))<(3.0*param.ArtifactTh) && ii<(length(raw_data)-s*2)%2x up/down +1x for wiggle
        current_section = cat(2,current_section,dtrn(ii:ii+s-1));
    else
        if length(current_section)>(param.MinSecLength*sr)

            i = ii-length(current_section);
            data_artifact_rmvd(i:ii-1)= detrend(current_section);

            %either this or a loop for each sw_new
            current_section = [];
        else
            current_section = [];
            continue
        end
        continue
    end
    swswaitbar(ii/(length(raw_data)-s), wb);

end
close(wb);

%update channel data
Channels.ProcessedData(chan,:) = data_artifact_rmvd;
Channels.ArtifactTh(chan,:) = param.ArtifactTh;
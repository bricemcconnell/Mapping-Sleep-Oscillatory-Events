function [data, header] = edfread(filename)
%[data, header] = edfread(filename)
%yet another edf+ reader
%Copyleft 2016, eugene.kronberg@ucdenver.edu
%for edf+ see http://www.edfplus.info/specs/edfplus.html
% Full specification of EDF:
% (from http://www.edfplus.info/specs/edf.html)
% HEADER RECORD (we suggest to also adopt the 12 simple additional EDF+ specs)
% 8 ascii : version of this data format (0) 
% 80 ascii : local patient identification (mind item 3 of the additional EDF+ specs)
% 80 ascii : local recording identification (mind item 4 of the additional EDF+ specs)
% 8 ascii : startdate of recording (dd.mm.yy) (mind item 2 of the additional EDF+ specs)
% 8 ascii : starttime of recording (hh.mm.ss) 
% 8 ascii : number of bytes in header record 
% 44 ascii : reserved 
% 8 ascii : number of data records (-1 if unknown, obey item 10 of the additional EDF+ specs) 
% 8 ascii : duration of a data record, in seconds 
% 4 ascii : number of signals (ns) in data record 
% ns * 16 ascii : ns * label (e.g. EEG Fpz-Cz or Body temp) (mind item 9 of the additional EDF+ specs)
% ns * 80 ascii : ns * transducer type (e.g. AgAgCl electrode) 
% ns * 8 ascii : ns * physical dimension (e.g. uV or degreeC) 
% ns * 8 ascii : ns * physical minimum (e.g. -500 or 34) 
% ns * 8 ascii : ns * physical maximum (e.g. 500 or 40) 
% ns * 8 ascii : ns * digital minimum (e.g. -2048) 
% ns * 8 ascii : ns * digital maximum (e.g. 2047) 
% ns * 80 ascii : ns * prefiltering (e.g. HP:0.1Hz LP:75Hz) 
% ns * 8 ascii : ns * nr of samples in each data record (limit 61440 bytes = 30720 samples)
% ns * 32 ascii : ns * reserved
% 
% DATA RECORD 
% nr of samples[1] * integer : first signal in the data record 
% nr of samples[2] * integer : second signal 
% .. 
% .. 
% nr of samples[ns] * integer : last signal 
%each sample value is represented as a 2-byte integer in 2's complement format
%file format little-endian (from http://www.edfplus.info/)
%annotation (from http://www.eHeaderTemplatedfplus.info/specs/edfplus.html)
%As in EDF, the 'nr of samples in each data record' (NumberOfSamples)
%field in the header specifies how many 2-byte integers this 'EDF Annotations'
%signal occupies in each datarecord. But instead of storing 'ordinary signal'
%samples, those 2-byte integers are filled with characters.
%
%Time-stamped Annotations Lists:
%Onset<21>Duration<20>Annotation<20><0>
%
%Onset must start with a '+' or a '-' character and specifies
%the amount of seconds by which the onset of the annotated event
%follows ('+') or precedes ('-') the startdate/time of the file,
%that is specified in the header. 
%Duration must not contain any '+' or '-' and specifies the duration
%of the annotated event in seconds. If such a specification is not relevant,
%Duration can be skipped in which case its preceding <21> must also be skipped.
%After the time stamp, a list of annotations all sharing the same Onset
%and Duration may follow. Each annotation is followed by a single <20> and
%may not contain any <20>. A <0> follows after the last <20> of this TAL.
%In each data record, the first TAL must start at the first byte
%of the 'EDF Annotations signal'. Subsequent TALs in the same data record
%must follow immediately after the trailing <0> of the preceding TAL.
%A TAL, including its trailing <0>, may not overflow into another data record.
%Each event is annotated only once, even if its duration makes it extend
%into the time period of other data records. Unused bytes
%of the 'EDF Annotations' signal in the remainder of the data record are
%also filled with <0>. Additional 'EDF Annotations' signals may be defined
%according to the same specification. 
%
%<0>, <20>, <21> : the unprintable ASCII characters with byte value 0, 20, 21

%open edf file
edf = fopen(filename, 'r', 'ieee-le');
if edf==-1
    error(strcat(filename, ' not found or was an invalid filename'));
end

%first read header
header = read_header(edf);

%read data
data = read_edf_data(edf, header);

%scale data
data = scale_data(data, header);

%close edf file
fclose(edf);

function data = scale_data(data, header)
for ii=1:header.NumberOfSignals
    if header.IsAnnotation(ii)
        continue
    end
    data{ii}=data{ii}*header.YScale(ii)+header.YOffset(ii);
end

function header = read_header(edf)
header = struct( ...
    'Version', fread(edf, 8, '*char')', ...
    'PatientID', fread(edf, 80, '*char')', ...
    'RecordID', fread(edf, 80, '*char')', ...
    'StartDate', fread(edf, 8, '*char')', ...
    'StartTime', fread(edf, 8, '*char')', ...
    'HeaderSize', str2double(fread(edf, 8, '*char')'), ...
    'Reserved_01', fread(edf, 44, '*char')', ...
    'NumberOfRecords', str2double(fread(edf, 8, '*char')'), ...
    'DurationSeconds', str2double(fread(edf, 8, '*char')'), ...
    'NumberOfSignals', str2double(fread(edf, 4, '*char')'));
%numbef of signals
ns = header.NumberOfSignals;
%read the rest of header
header.Label = read_header_field(edf, ns, 16);
header.Transducer = read_header_field(edf, ns, 80);
header.PhysicalDimension = read_header_field(edf, ns, 8);
header.PhysicalMin = read_header_num_field(edf, ns, 8);
header.PhysicalMax = read_header_num_field(edf, ns, 8);
header.DigitalMin = read_header_num_field(edf, ns, 8);
header.DigitalMax = read_header_num_field(edf, ns, 8);
header.Filter = read_header_field(edf, ns, 80);
header.NumberOfSamples = read_header_num_field(edf, ns, 8);
header.Reserved_02 = read_header_field(edf, ns, 32);
%extra fields - not part of the header but usefull
header.XUnits = 'sec';%always seconds
header.XScale = header.DurationSeconds ./ header.NumberOfSamples;
header.YUnits = header.PhysicalDimension;
header.YScale = (header.PhysicalMax - header.PhysicalMin) ./ ...
    (header.DigitalMax - header.DigitalMin);
header.YOffset = mean([header.PhysicalMax, header.PhysicalMin], 2);
%to make it easy to separate annotations from real signals
header.IsAnnotation = false(header.NumberOfSignals, 1);
for ii=1:header.NumberOfSignals
    if strcmp(deblank(header.Label(ii,:)), 'EDF Annotations')
        header.IsAnnotation(ii) = true;
    end
end

function field = read_header_field(edf, ns, bytes)
%read multiple fields - keep in ascii
field = cell(ns,1);
for ii=1:ns
    field{ii} = fread(edf, bytes, '*char')';
end

function field = read_header_num_field(edf, ns, bytes)
%read multiple fields and convert to double
field = zeros(ns,1);
for ii=1:ns
    field(ii) = str2double(fread(edf, bytes, '*char')');
end

function data = read_edf_data(edf, header)
%different signals could have different number of samples
%so we store data is as a cell array
data = cell(header.NumberOfSignals, 1);
for ii=1:header.NumberOfSignals
    if header.IsAnnotation(ii)
        data{ii} = cell(header.NumberOfRecords, 1);
    else
        data{ii} = zeros(header.NumberOfSamples(ii), header.NumberOfRecords);
    end
end
for jj=1:header.NumberOfRecords
    rec = read_edf_record(edf, header);
    for ii=1:header.NumberOfSignals
        if header.IsAnnotation(ii)
            data{ii}{jj} = rec{ii};
        else
            data{ii}(:,jj) = rec{ii};
        end
    end
end

function data = read_edf_record(edf, header)
data = cell(header.NumberOfSignals, 1);
for ii=1:header.NumberOfSignals
    if header.IsAnnotation(ii)
        %there are 2*NumberOfSamples bytes in annotations record
        data{ii} = read_annotations(edf, 2*header.NumberOfSamples(ii));
    else
        %read data as int16 (2's compliment - it must be)
        data{ii} = fread(edf, header.NumberOfSamples(ii), '*int16');
    end
end

function ann = read_annotations(edf, bytes)
block = fread(edf, [1 bytes], '*char');
ann = struct('Onset', [], 'Duration', [], 'Annotation', '');
%byte 20 separates time stamp from annotation
byte20 = find(block==20);
if isempty(byte20)
    %no annotations
    return
end
%first_byte of annotation
ann_first_byte = byte20(1:2:end)+1;
ann_last_byte = byte20(2:2:end)-1;
%firts byte of the time stamp
time_first_byte = [1 byte20(2:2:end)+2];
time_last_byte = byte20(1:2:end)-1;
%number of annotations
num = length(time_last_byte);
%init struct array (ann is 1 by num struct)
ann(num).Onset = [];
for ii=1:num
    byte21 = find(block(time_first_byte(ii):time_last_byte(ii))==21,1,'first');
    if isempty(byte21)
        %there is no Duration for that annotation
        ann(ii).Onset = str2double(block(time_first_byte(ii):time_last_byte(ii)));
        ann(ii).Duration = 0;
    else
        ann(ii).Onset = str2double(block(time_first_byte(ii):time_first_byte(ii)+byte21-2));
        ann(ii).Duration = str2double(block(time_first_byte(ii)+byte21:time_last_byte(ii)));
    end
    ann(ii).Annotation = char(block(ann_first_byte(ii):ann_last_byte(ii)));
end

function [first, last] = ConvertTimeToSamples(sr, start_time, end_time)
%convert time (in hh:mm:ss format) to indexes
%sr - sampling rate (samples per second)
%start_time - first data point ('hh:mm:ss')
%end_time - last data point ('hh:mm:ss')

%that how it was in slow-wave extractor:
% dn = datenum('0:0:0', 'HH:MM:SS');
% sec = datenum('0:0:1', 'HH:MM:SS') - dn;%second as portion of datenum
% start_time = 1 + round(edf.Header.NumberOfSamples(chan) * ...
%     (datenum(wave_time_param.StartTime, 'HH:MM:SS') - dn)/sec);
% end_time = 1 + round(edf.Header.NumberOfSamples(chan) * ...
%     (datenum(wave_time_param.EndTime, 'HH:MM:SS') - dn)/sec);

%Convert from string to seconds
start_sec = sum(sscanf(start_time,'%f:%f:%f').*[3600;60;1]);
end_sec = sum(sscanf(end_time,'%f:%f:%f').*[3600;60;1]);

%calculate first and last sample indexes
first = 1 + round(start_sec*sr);
last = round(end_sec*sr);

%error if first>last
if first>last
    error('Provided Start Time is greater than End Time.')
end
function grouped_events = GroupSWEvents(sw_param, event_markers, sw_indx_preserved, sw_event_data, start_time_offset)
%MinPosHalfWave
%MaxPosHalfWave    

%figure out slow wave number (1st, 2nd, ...) in the train
events_before = zeros(1, sw_event_data.NumberPairs);
for zcp=2:sw_event_data.NumberPairs
    inter_wave_gap = sw_event_data.ZeroCrossPairs(1,zcp)-sw_event_data.ZeroCrossPairs(2,zcp-1);
    inter_wave_gap = inter_wave_gap/event_markers.SampleRate;%seconds
    if inter_wave_gap > sw_param.MinPosHalfWave && inter_wave_gap < sw_param.MaxPosHalfWave
        events_before(zcp) = events_before(zcp-1) + 1;   
    end
end

events_after = zeros(1, sw_event_data.NumberPairs);
for zcp=sw_event_data.NumberPairs:-1:2
    inter_wave_gap = sw_event_data.ZeroCrossPairs(1,zcp)-sw_event_data.ZeroCrossPairs(2,zcp-1);
    inter_wave_gap = inter_wave_gap/event_markers.SampleRate;%seconds
    if inter_wave_gap > sw_param.MinPosHalfWave && inter_wave_gap < sw_param.MaxPosHalfWave
        events_after(zcp-1) = events_after(zcp) + 1;
    end
end

%only nine events before or after we care
before_after = 4;
events_after(events_after>before_after) = before_after;
events_before(events_before>before_after) = before_after;

%now we can put both in one index
event_number = 10*events_before + events_after;

%event indexes
event_ind = -event_markers.PreEventDur:event_markers.PostEventDur;
event_length = length(event_ind);
%event_index = event_markers.PreEventDur + 1;%next after pre-event samples

%Center wave around selected event marker
event_center_marker_opts = [sw_event_data.ZeroCrossPairs(1,:); sw_event_data.TroughIndex; sw_event_data.ZeroCrossPairs(2,:); sw_event_data.PeakIndex; sw_event_data.ZeroCrossPairs(3,:)];
event_center_marker = event_center_marker_opts(sw_param.EventCenterMarkerI, :);
sw_ts = zeros(event_length, sw_event_data.NumberPairs);%slow wave timeseries
wave_time = zeros(event_length,sw_event_data.NumberPairs);
for ii=1:sw_event_data.NumberPairs
    iii = event_center_marker(ii)+event_ind;
    sw_ts(:,ii) = sw_indx_preserved(iii);
    wave_time(:,ii) = iii;
end

%get data chunks just before selected waves:
baselinedur = event_length;%same number of samples as main wave
base_ind = -baselinedur:-1;

%sort
first_sample = sort(wave_time(1,:));
last_sample = [1 sort(wave_time(end,:))];
baseline = zeros(baselinedur, sw_event_data.NumberPairs);
base_time = zeros(baselinedur, sw_event_data.NumberPairs);
keep = false(1,sw_event_data.NumberPairs);

for ii=1:sw_event_data.NumberPairs
    if first_sample(ii)-last_sample(ii)>baselinedur
        base_time(:,ii) = first_sample(ii)+base_ind;
        baseline(:,ii)=sw_indx_preserved(base_time(:,ii));
        if events_before(ii)==0
            keep(ii) = true;
        end
    end
end

%keep selected only
baseline = baseline(:,keep);
base_time = base_time(:,keep);

%adjust indexes for start time
zero_cross_pairs_adj = sw_event_data.ZeroCrossPairs+start_time_offset;
base_time_adj = base_time+start_time_offset;
wave_time_adj = wave_time+start_time_offset;

%data structure
grouped_events = struct(...
    'Trough', sw_event_data.Trough, ...
    'TroughIndex', sw_event_data.TroughIndex, ...
    'Peak', sw_event_data.Peak, ...
    'PeakIndex', sw_event_data.PeakIndex, ...
    'EventNumber', event_number, ...
    'WaveTime', wave_time_adj, ...
    'SWTimeSeries', sw_ts, ...
    'BaseLine', baseline, ...
    'BaseTime', base_time_adj, ...
    'ZeroCrossPairs', zero_cross_pairs_adj);
end

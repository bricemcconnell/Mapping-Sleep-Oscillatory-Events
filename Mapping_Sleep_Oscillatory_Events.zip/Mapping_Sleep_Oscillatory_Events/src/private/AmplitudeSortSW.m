function sw_events = AmplitudeSortSW(event_features,  sw_param)
%SW Params used here:
%NegHalfWaveLowerPercent
%NegHalfWaveUpperPercent
%DiscardNStd - not set by user. Maybe doesn't need to be a param?
%PosHalfWaveLowerPercent
%PosHalfWaveUpperPercent

%sort by trough amplitudes
% trough = trough(sind);
[~, trind] = sort(event_features.Trough,2,'ascend');
n_smaller = floor((1-sw_param.NegHalfWaveLowerPercent)*length(event_features.Trough));%number of events smaller than lower threshold
n_bigger = floor((1-sw_param.NegHalfWaveUpperPercent)*length(event_features.Trough))+1;%number of events larger than upper threshold
if sw_param.NegHalfWaveUpperPercent==1.0%if 100% selcted, n_above=0, remove the outliers
    n_bigger = sum(event_features.Trough>(mean(event_features.Trough)+sw_param.DiscardNStd*std(event_features.Trough)))+1;%discard false events
end
trind = sort(trind(n_bigger:n_smaller));%take the indexes within the defined percentages

%sort by peak amplitudes
[~, pkind] = sort(event_features.Peak,2,'descend');
n_smaller = floor((1-sw_param.PosHalfWaveLowerPercent)*length(event_features.Peak));%number of events smaller than lower threshold
n_bigger = floor((1-sw_param.PosHalfWaveUpperPercent)*length(event_features.Peak))+1;%number of events larger than upper threshold
if sw_param.NegHalfWaveUpperPercent==1.0%if 100% selcted, n_above=0, remove the outliers
    n_bigger = sum(event_features.Peak>(mean(event_features.Peak)+sw_param.DiscardNStd*std(event_features.Peak)))+1;%discard false events
end
pkind = sort(pkind(n_bigger:n_smaller));%take the indexes within the defined percentages

%find overlapping indexes
sind=[];
for ii=1:length(event_features.Trough)
    if any(ii==pkind)&&any(ii==trind)
        sind = cat(2,sind,ii);
    end
end

%final selection of events
zero_cross_pairs = event_features.ZeroCrossPairs(:,sind);

trough = event_features.Trough(sind);
peak = event_features.Peak(sind);

trough_index = event_features.TroughIndex(sind);
peak_index = event_features.PeakIndex(sind);

np = size(sind,2);%kept this many total events

%data structure
sw_events = struct(...
    'Trough', trough, ...
    'TroughIndex', trough_index,...
    'Peak', peak, ...
    'PeakIndex', peak_index, ...
    'ZeroCrossPairs', zero_cross_pairs, ...
    'NumberPairs', np);
end

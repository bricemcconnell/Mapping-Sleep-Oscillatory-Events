function [channel, StageData] = AdjustChannelDataToFitStaging(channel, StageData)
    st_length_diff = length(channel.Part)-length(StageData.Data.AdjStages);
    if (st_length_diff)/channel.SR > StageData.Data.EpochLength
        error('Length between staging data and channel data is greater than one epoch.')
    elseif st_length_diff < 0
        %Staging data is longer than eeg data, so fix length to match
        adj_stage_end_time = length(StageData.Data.AdjStages) + st_length_diff;
        StageData.Data.AdjStages = StageData.Data.AdjStages(1:adj_stage_end_time);
    else
        %Staging data only occurs in epoch length sizes, so last part of
        %data that is less than an epoch does not have staging data,
        %therefore it is removed from channel data for processing
        channel.EndTime = channel.EndTime-st_length_diff;
        channel.Part = channel.Part(1:channel.EndTime);
    end
end
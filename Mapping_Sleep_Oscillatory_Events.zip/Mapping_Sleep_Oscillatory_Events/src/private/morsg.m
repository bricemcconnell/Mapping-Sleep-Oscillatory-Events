function sg = morsg(x,f,n,fs)
%sg = morsg(x,f,n,fs) calculates spectrogram based on Morlet wavlets
%x - time series
%f - vector of frequencies bins [Hz]
%n - number of waves in wavelet
%fs - sampling friquency (sampling rate [Hz])

%number of frequency bins
nf = length(f);

%number of time points
nt = length(x);

sg = zeros(nf, nt);

nCycles = linspace(n(1),n(end),nf);

for ii=1:nf
    %this would convert inputs and call cmorwavf:
    w = ComplexMorlet(f(ii),nCycles(ii),fs);
    sg(ii,:) = abs(conv(x,w,'same'));%absolute value
end

end

function w = ComplexMorlet(fc,n,fs)
% convert inputs and call cmorwavf
%fc - center frequency [Hz]
%n - number of waves in wavelet
%fs - sampling friquency (sampling rate [Hz])
%
% wavelet expression:
% PSI(X) = ((pi*FB)^(-0.5))*exp(2*i*pi*FC*X)*exp(-X^2/FB)
% where X is grid to calculate the function

fb = (n/fc/2)^2;%"bandwidth" of the wavelet
Ub = n/fc;%upper limit [sec]
Lb = -Ub;%lower limit [sec]
N = round(2*Ub*fs);%number of samples in Lb:Ub interval
w = cmorwavf(Lb,Ub,N,fb,fc);
end
function filename = PrimaryProcessing(filein, chan, output_dir)
[~, name, fmt] = fileparts(filein.FileName);
filename = fullfile(output_dir, strcat(name, '_ChannelInfo','.sws'));
if isfile(filename)
    mapChanData = matfile(filename,'Writable',false);
    if ismember(chan, mapChanData.Channel)
        return
    end
end
if strcmp(fmt,'.edf')
    PrimaryProcessingEDF(filein, chan, filename);
else 
    error(strcat('Input file ', filein, ' not supported. Try again with .edf'))
end

function PrimaryProcessingEDF(edf, chan, filename)
%Preform the processing to create the primary data struct
% inputs: raw edf data
% outputs: none. Saves mapped data file

ChannelStr = edf.ChannelList;
AllChanSampleRate = edf.Header.NumberOfSamples / edf.Header.DurationSeconds;
if size(edf.Data,1)>size(edf.Data,2)
    edf.Data = edf.Data';
end

counter = 0;
Channel = zeros(length(chan),1);
SamplingRate = zeros(length(chan),1);
RawRun = zeros(length(chan),length(edf.Data{chan(1)}(:)));
for i = 1:length(chan)
    counter = counter + 1;
    RawRun(counter,:) = edf.Data{chan(i)}(:);
    Channel(counter) = chan(i);
    SamplingRate(counter) = AllChanSampleRate(chan(i));
end
ProcessedData = zeros(size(RawRun));
IsProcessed = false(length(chan),1);
ArtifactTh = zeros(length(chan),1);
Duration = edf.Duration;
FromFile = edf.FileName;

save(filename, 'Channel','ChannelStr', 'SamplingRate','RawRun','ProcessedData','IsProcessed','ArtifactTh','Duration','FromFile','-v7.3');
clear Channel ChannelStr SamplingRate RawRun ProcessedData ArtifactTh IsProcessed

function label = UniqueLabel(event_data, label)
%make label unique
old_label = label;
n = length(event_data);
all_labels = cell(1,n);
for ii=1:n
    all_labels{ii} = event_data{ii}.Label;
end
nn = 0;
while any(strcmp(label, all_labels))
    nn = nn + 1;
    label = sprintf('%s (%d)', old_label, nn);
end
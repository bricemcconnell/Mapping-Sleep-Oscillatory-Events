function [ sw_event_data ] = FilterHalfWaveWithinStageMask(event_data, st_mask)
    %apply the mask to relevant variables
    %adjust indexes for start time
    %adjust if mask too short
    
    %spindles
    sw_mask = st_mask(event_data.ZeroCrossPairs);
    sw_mask = repmat(~any(~sw_mask),[3 1]); %Any zcp where one pair is outside of stage, make both of mask 0

    zero_cross_pairs_adj_st(1,:) = event_data.ZeroCrossPairs(1,sw_mask(1,:));
    zero_cross_pairs_adj_st(2,:) = event_data.ZeroCrossPairs(2,sw_mask(2,:));
    zero_cross_pairs_adj_st(3,:) = event_data.ZeroCrossPairs(3,sw_mask(3,:));
    zero_cross_pairs_final = zero_cross_pairs_adj_st;
    
    %create simple mask
    mask = sw_mask(1,:);
    
    %peaks and troughs of waves
    
    trough_st = event_data.Trough(find(mask));
    trough = trough_st;
    trough_ind = event_data.TroughIndex(find(mask));
    
    peak_st = event_data.Peak(find(mask));
    peak = peak_st;
    peak_ind = event_data.PeakIndex(find(mask));

%data structure
sw_event_data = struct(...
    'Trough', trough, ...
    'TroughIndex', trough_ind, ...
    'Peak', peak, ...
    'PeakIndex', peak_ind, ...
    'ZeroCrossPairs', zero_cross_pairs_final);
return
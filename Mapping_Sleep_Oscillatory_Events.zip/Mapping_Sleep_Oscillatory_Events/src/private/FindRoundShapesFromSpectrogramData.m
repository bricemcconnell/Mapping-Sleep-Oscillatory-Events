function [circle_data, time_freq_data] = FindRoundShapesFromSpectrogramData(this_sg_data, sg_time, sg_freq, detect_param)       
    new_sg_data = [];
    num_reps = 10;
    for t = 1:size(this_sg_data,1)
        index = num_reps*(t-1)+1;
        temp_index = size(this_sg_data,1)-t+1;
        new_sg_data(index:index+num_reps-1,:) = repmat(this_sg_data(temp_index,:),num_reps,1);
    end
    I = rescale(new_sg_data);

    bw = imbinarize(I,0.65);
    
    % Remove the Noise
    bw = bwareaopen(bw,30);
    
    % Fill gaps
    se = strel('disk',2);
    bw = imclose(bw,se);
    
    % Fill any holes
    bw = imfill(bw,'holes');

    % Find the Boundaries
    [B,L] = bwboundaries(bw,'noholes');

    % Adjust image based on time and freq
    pixel_time_length = size(I, 2);
    pixel_freq_length = size(I, 1);
    pixel_time_array = linspace(sg_time(1),sg_time(end),pixel_time_length);
    pixel_freq_array = linspace(sg_freq(end),sg_freq(1),pixel_freq_length);
    pixel_time_ratio = (pixel_time_array(end)-pixel_time_array(1))/pixel_time_length;
    pixel_freq_ratio = (pixel_freq_array(1)-pixel_freq_array(end))/pixel_freq_length;
    
    % Get circle measurements
    circle_measurements = regionprops(L,I,'all');
    allCircleAreas = [circle_measurements.Area];
    allCircleIntensities = [circle_measurements.MeanIntensity];
    allCircleCircularities = [circle_measurements.Circularity];

    % Filter based on size & intensity
    allowableAreaIndexes = allCircleAreas >= detect_param.MinArea & allCircleAreas <= detect_param.MaxArea;
    allowableIntensityIndexes = (allCircleIntensities >= detect_param.MinIntensity) & (allCircleIntensities <= detect_param.MaxIntensity);
    allowableRoundnessIndexes = allCircleCircularities > detect_param.RoundFactor;
    keeperIndexes = find(allowableIntensityIndexes & allowableAreaIndexes & allowableRoundnessIndexes);
    if isempty(keeperIndexes)
        circle_data = [];
        time_freq_data = [];
        return
    end
    boundary_data = B(keeperIndexes);
    circle_measurements = circle_measurements(keeperIndexes);
    temp_circle_measurements = struct2cell(circle_measurements);
    centroid_data = temp_circle_measurements(2,:);

    circle_data = struct(...
        'BoundaryData', {boundary_data}, ...
        'CentroidData', {centroid_data} ...
        );

    time_freq_data = struct(...
        'PixelTimeArray', pixel_time_array, ...
        'PixelFreqArray', pixel_freq_array, ...
        'PixelTimeRatio', pixel_time_ratio, ...
        'PixelFreqRatio', pixel_freq_ratio ...
        );

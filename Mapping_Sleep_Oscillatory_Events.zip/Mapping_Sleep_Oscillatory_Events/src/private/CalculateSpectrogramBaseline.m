function base = CalculateSpectrogramBaseline(baseline, fs, time_arr, freq_arr ,wave_n)
x = time_arr;
%invoked
wb = swswaitbar(0,'Please wait...','Name', 'Calculating Spectrogram Baseline');
y = baseline;%there are no events for the base line
nb = size(y,2); %number of baseline windows 
base = zeros(length(freq_arr), size(x,1), nb);
for ii=1:nb
    base(:,:,ii) = morsg(y(:,ii),freq_arr,wave_n,fs);
    swswaitbar((ii/nb), wb);
end
close(wb);
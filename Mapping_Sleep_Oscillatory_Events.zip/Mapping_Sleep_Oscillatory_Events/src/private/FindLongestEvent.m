function ref_wave = FindLongestEvent(wave_ind, event_data)

%extract wave & reference wave pointers, determine how many channels
ref_pointers = [];
for ww=1:length(wave_ind)
    w = wave_ind(ww);
    ref_pointers = cat(1,ref_pointers, event_data{w}.ReferencePointer);
end

ref_wave_lengths = [];
for rr = 1:length(ref_pointers)
    r = ref_pointers(rr);
    len = event_data{r}.EndIndex-event_data{r}.StartIndex;
    ref_wave_lengths = cat(1,ref_wave_lengths,len);
end
[~,max_ind] = max(ref_wave_lengths); %find longest chosen wave
r_ind = ref_pointers(max_ind);
ref_wave = event_data{r_ind};

end
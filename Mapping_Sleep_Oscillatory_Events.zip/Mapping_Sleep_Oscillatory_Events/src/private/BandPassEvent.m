function bandpass_data = BandPassEvent(bp_param, event_data, wave_ind, chan_file)

if isempty(event_data)
    return
end

mapChanData = matfile(chan_file,'Writable',false);

%extract data information
w = event_data{wave_ind};

%extract general data
chan = find(mapChanData.Channel == bp_param.Channel);
ChanList = mapChanData.ChannelStr;
chan_str = ChanList(mapChanData.Channel(chan,:));
fs = mapChanData.SamplingRate(chan,:);

%select unique label
bp_param.Label = UniqueLabel(event_data, bp_param.Label);

%more verbose label - TODO: I don't think this is needed anymore
label = sprintf('%s %s %s-%s [bandpass %.3f to %.3f Hz]',...
    bp_param.Label, chan_str,...
    w.StartTime,w.EndTime,...
    bp_param.MinFrequency,bp_param.MaxFrequency);

%extract data
part = mapChanData.ProcessedData(chan,w.StartIndex:w.EndIndex);

%ALIGNMENT and window widening
baseline = w.BaseLineIndex;
eegForAlignment = FilterDataSW(part,fs,w.MinFrequency,w.MaxFrequency,w.FilterOrder);
waveLocations = w.WaveIndex-w.StartIndex;
wide_pre_time = round(bp_param.LeftFrame*fs);
wide_post_time = round(bp_param.RightFrame*fs);
%create wide windows
wideWaveWindows = zeros(size(waveLocations,1)+wide_pre_time+wide_post_time,size(waveLocations,2));
for ww=1:size(waveLocations,2)
    wideWaveWindows(:,ww) = -wide_pre_time+waveLocations(1,ww):waveLocations(end,ww)+wide_post_time;
end
wideBaseline = zeros(size(baseline,1)+wide_pre_time+wide_post_time,size(baseline,2));
for ww=1:size(baseline,2)
    wideBaseline(:,ww) = -wide_pre_time+baseline(1,ww):baseline(end,ww)+wide_post_time;
end
    
%extract event numbers
event_number = w.EventNumber;

%chop ends if beyond bounds
while wideWaveWindows(1)<=eegForAlignment(1) 
    wideWaveWindows = wideWaveWindows(:,2:end);
    event_number = event_number(2:end);
end
while wideWaveWindows(end)>length(eegForAlignment)
    wideWaveWindows = wideWaveWindows(:,1:end-1);
    event_number = event_number(1:end-1);
end

waves = eegForAlignment(wideWaveWindows);
eventIndex = w.EventIndex+wide_pre_time;

nOffCenter=25;
centerRegion = -nOffCenter:nOffCenter;
centerRegion = centerRegion+eventIndex+1;
for ii=1:size(waves,2)
    if w.Type == EventType.SlowWaves
        [~,peakValueLocBP] = max(abs(waves(centerRegion,ii)));
    else
        [~,peakValueLocBP] = max(waves(centerRegion,ii));
    end
    del = eventIndex-(peakValueLocBP+centerRegion(1)-1);
    wideWaveWindows(:,ii) = wideWaveWindows(1,ii)-del:wideWaveWindows(end,ii)-del;
end

%detrend and filter channel data
eeg = FilterDataSW(part, fs, ...
    bp_param.MinFrequency, bp_param.MaxFrequency, bp_param.FilterOrder);

%chop ends if beyond bounds
base = wideBaseline-w.StartIndex;
while base(1)<=0
    base = base(:,2:end);
end
while base(end)>w.EndIndex
    base = base(:,1:end-1);
end

bandpass_params = struct(...
    'MinFrequency',  bp_param.MinFrequency, ...
    'MaxFrequency', bp_param.MaxFrequency, ...
    'FilterOrder', bp_param.FilterOrder);

bandpass_data = struct(...
    'Label', label, ...
    'StartIndex', w.StartIndex, ... 
    'StartTime', w.StartTime, ... 
    'EndIndex', w.EndIndex, ... 
    'EndTime', w.EndTime, ... 
    'EventIndex', eventIndex, ...
    'TimeSeries', eeg(wideWaveWindows), ... 
    'BaseLineIndex', base, ...
    'BaseLine', eeg(base), ...
    'WaveIndex', wideWaveWindows, ...
    'EventNumber', event_number, ...
    'Parameters', bandpass_params);
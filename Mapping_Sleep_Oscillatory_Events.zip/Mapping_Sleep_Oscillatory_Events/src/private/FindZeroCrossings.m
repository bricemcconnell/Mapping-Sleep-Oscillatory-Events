function [zero_cross_pairs, sw_indx_preserved] = FindZeroCrossings(channel, sw_param)
%SW Params used here:
%Artifact Width - not set by user. Maybe doesn't need to be a param?
%MinFrequency
%MaxFrequency
%FilterOrder - not set by user. Maybe doesn't need to be a param?

%%TODO: Can eventually try to split this into filtering and ZCP (hard with for
%%loop right now though)

%detrend portion
dtrn = detrend(channel.Part);

%eliminate regions with high range
sw = [];
sw_indx_preserved = zeros(1,length(channel.Part));
currentSection = [];
zero_cross_pairs = [];

%step size
step = round(channel.SR*sw_param.ArtifactWidth);

%swswaitbar
wb = swswaitbar(0,'Please wait...', 'Name', 'Zero Crossing Detection in Progress');

for ii = 1:step:(length(channel.Part)-step)
    if any(dtrn(ii:ii+step-1))~=0 && ii<(length(channel.Part)-step*2)%find parts that arent == 0 (artifact removed)
        if any(dtrn(ii+1:ii+step)==0)
            %%%IS THIS THE 0 PIN SHIFTING??
            jj = find(dtrn(ii:ii+step)==0,1,'first');
            currentSection = cat(2,currentSection,dtrn(ii:jj));
        else
            currentSection = cat(2,currentSection,dtrn(ii:ii+step-1));
        end
    else
    sw_new = FilterDataSW(currentSection, channel.SR, sw_param.MinFrequency,...
        sw_param.MaxFrequency, sw_param.FilterOrder);
    i = ii-length(currentSection);
    sw_indx_preserved(i:ii-1) = sw_new;

    %find positive-to-negative zero crossings for slow waves
    zero_cross_l = find(diff(sw_new>0)<0);
    zero_cross_r = find(diff(sw_new>0)>0);

    %adjust
    zero_cross_l = zero_cross_l+i-1;
    zero_cross_r = zero_cross_r+i-1;

    if isempty(zero_cross_l) || isempty(zero_cross_r)
        continue
    elseif zero_cross_l(1)>zero_cross_r(1)
        zero_cross_r = zero_cross_r(2:end);
    elseif zero_cross_r(end)<zero_cross_l(end)
        zero_cross_l = zero_cross_l(1:end-1);
    end

    while length(zero_cross_l)~=length(zero_cross_r)
        if length(zero_cross_l)>length(zero_cross_r)
            zero_cross_l = zero_cross_l(1:end-1);
        end
        if length(zero_cross_r)>length(zero_cross_l)
            zero_cross_r = zero_cross_r(2:end);
        end
    end

    %get positive-to-negative pairs
    new_pairs = [zero_cross_l; zero_cross_r];
    zero_cross_pairs = cat(2,zero_cross_pairs,new_pairs);

    %either this or a loop for each sw_new
    sw = cat(2,sw,sw_new);
    currentSection = [];
    end
    swswaitbar(ii/(length(channel.Part)-step), wb);
end
close(wb);
end
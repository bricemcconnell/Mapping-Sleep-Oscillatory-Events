function FFTFiltering(chan_file, chan, param)

mapChanData = matfile(chan_file,'Writable',true);

%remove artifact
og_data = mapChanData.RawRun;
new_data = og_data;

%step size
sr = mapChanData.SamplingRate;
s = sr*param.ArtifactWidth; 

L = s;
f2 = sr*(0:(L-1))/L;
[~, freq_start_ind] = min(abs(f2-param.FreqStart));
[~, freq_end_ind] = min(abs(f2-param.FreqEnd));

%swswaitbar
wb = swswaitbar(0,'Please wait...', 'Name', 'FFT filtering in Progress');

%figure;
for ii = 1:s:(length(og_data)-s)
    current_section = ii:ii+s-1;
    current_power = abs(fft(og_data(current_section))/L);
    if range(current_power(freq_start_ind:freq_end_ind))>(param.PowerTh)
        new_data(current_section)=0;
    end
    swswaitbar(ii/(length(og_data)-s), wb);
end
close(wb);
mapChanData.ProcessedData(chan,:) = new_data;
end
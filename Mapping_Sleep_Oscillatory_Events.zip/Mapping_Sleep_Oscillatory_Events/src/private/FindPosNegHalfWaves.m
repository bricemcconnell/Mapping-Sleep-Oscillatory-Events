function [event_features] = FindPosNegHalfWaves(zero_cross_pairs, sw_indx_preserved, sw_param, event_markers)
%SW Params used here:
%DetectThreshold = "Detection Threshold"
%MinNegHalfWave
%MaxNegHalfWave
%MinPosHalfWave
%MaxPosHalfWave

%Find Slow Waves using Zero Cross Pairs based on filter data: trough gap defined by user, amplitude
    np = size(zero_cross_pairs,2);%number of pairs
    keeper_ind = true(1,np-1);%index for pairs to keep
    peak = zeros(1,np-1);%peak value for each event
    trough = zeros(1,np-1);%trough value for each event
    trough_ind = zeros(1,np-1);%trough index
    peak_ind = zeros(1,np-1);%peak index
    
    sw_upper_th = sw_param.DetectThreshold;
    for zcp=1:np-1
        %is sw dip gap too short or too long?
        gap = diff(zero_cross_pairs(1:2,zcp))/event_markers.SampleRate; %seconds
        keeper_ind(zcp) = gap > sw_param.MinNegHalfWave && gap < sw_param.MaxNegHalfWave;
        pair_ind = zero_cross_pairs(1,zcp):zero_cross_pairs(2,zcp);
        
        %return trough index
        [trough(zcp), ti] = min(sw_indx_preserved(pair_ind));
        trough_ind(zcp) = ti + pair_ind(1);
        
        %if too close to the ends of the time series:
        if trough_ind(zcp) < event_markers.PreEventDur || ...
                trough_ind(zcp) > length(sw_indx_preserved) - event_markers.PostEventDur
            keeper_ind(zcp) = false;
        end
        
        %sw pair gap
        pair_to_pair_ind = zero_cross_pairs(2,zcp):zero_cross_pairs(1,zcp+1);
        
        %if too far apart, define the refract period as 2x right zerocross to peak
        if length(pair_to_pair_ind)/event_markers.SampleRate > sw_param.MaxPosHalfWave
            le = floor(pair_to_pair_ind(1));
            ri = floor(pair_to_pair_ind(1)+event_markers.SampleRate*sw_param.MaxPosHalfWave);
            [peak(zcp), peak_ind_local] = max(sw_indx_preserved(le:ri));
            peak_ind(zcp) = peak_ind_local + le - 1;
            zero_cross_pairs(3,zcp) = ri;
            delt_peak = peak_ind(zcp)-le;
            %set false if peak too far
            if delt_peak > event_markers.SampleRate*sw_param.MaxPosHalfWave/2.0
                keeper_ind(zcp) = false;
            end
        elseif length(pair_to_pair_ind)/event_markers.SampleRate > sw_param.MinPosHalfWave
            [peak(zcp), peak_ind_local] = max(sw_indx_preserved(pair_to_pair_ind));
            peak_ind(zcp) = peak_ind_local + pair_to_pair_ind(1);
            zero_cross_pairs(3,zcp) = pair_to_pair_ind(end);
        else
            %set false if peak too close
            keeper_ind(zcp) = false;
        end
        
        %skip too high peaks (or too low trough)
        if peak(zcp) > sw_upper_th || trough(zcp) < -sw_upper_th
            keeper_ind(zcp) = false;
        end
    end
 
    zero_cross_pairs = zero_cross_pairs(:,keeper_ind);
    peak = peak(keeper_ind);
    trough = trough(keeper_ind);
    peak_ind = peak_ind(keeper_ind);
    trough_ind = trough_ind(keeper_ind);
    if isempty(zero_cross_pairs)
        %should be shown in main figure - FIXME
        fprintf('\nNo slow waves identified.\n')
        fprintf('All Gaps are too short (or too long) or amplitude is too high.\n')
        fprintf('Try altering SW parameters.\n')
        return
    end

    %data structure
    event_features = struct(...
        'Trough', trough, ...
        'TroughIndex', trough_ind, ...
        'Peak', peak, ...
        'PeakIndex', peak_ind, ...
        'ZeroCrossPairs', zero_cross_pairs);
return
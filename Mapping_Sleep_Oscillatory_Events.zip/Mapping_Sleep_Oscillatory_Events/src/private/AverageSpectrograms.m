function sg_data = AverageSpectrograms(files)
%%This function takes in an array of filenames that contain wavelet
%%spectrogram data and averages all the selected spectrograms together
sg_field = [];
sum_events = 0;
individual_sg_data = [];
subject_ids = [];
for i=1:length(files)
    file = matfile(files{i},'Writable',false);
    if length(file.EventNumber) > 1
        warning('Averaging multiple file averages together. Data may not be accurate.')
    end
    sg_field = cat(3,sg_field, file.Spectrogram);
    sum_events = sum_events + file.EventNumber;
    individual_sg_data = cat(3, individual_sg_data, file.Spectrogram);
    subject_ids = cat(2, subject_ids, file.SubjectId);
end

if isempty(sg_field)
    sg_data = [];
    return
end

%take mean
mean_field = mean(sg_field,3);
vr = var(mean_field);

%data structure
sg_data = struct(...
    'Label', 'Multi-Wave Mean', ...
    'EventNumber', sum_events, ...
    'NumberOfEventGroups', length(files), ...
    'Spectrogram', mean_field, ...
    'SubjectId', subject_ids, ...
    'IndividualSpectrograms', individual_sg_data, ...
    'Variance', vr, ...
    'BaseLine', [], ...
    'Frequency', file.Frequency,...
    'Time', file.Time);
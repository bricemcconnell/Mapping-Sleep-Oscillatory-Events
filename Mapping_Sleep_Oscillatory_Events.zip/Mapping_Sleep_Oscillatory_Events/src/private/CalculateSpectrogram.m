function spectrogram_data = CalculateSpectrogram(sg_param, time_series, fs)
x = time_series;
f = sg_param.MinFrequency:sg_param.StepFrequency:sg_param.MaxFrequency;
n = sg_param.WaveNumber;

ne = size(x,2);%number of events
sg = zeros(length(f), size(x,1), ne);
wb = swswaitbar(0,'Please wait...', 'Name','Calculating Spectrograms');
for ii=1:ne
    sg(:,:,ii) = morsg(x(:,ii),f,n,fs);
    swswaitbar(ii/ne, wb);
end
close(wb);

spectrogram_data = struct(...
    'Spectrogram', sg, ...
    'FrequencyRange', f);
end



function PlotRoundShapesFromSpectrogram(round_shape_data, plot_params)

for r = 1:length(round_shape_data)
    %% Loop over round objects found and plot boundaries / centroids
    num_circles = round_shape_data{r}.NumCircles;
    line_colors = {'#77AC30','#0072BD','r','#EDB120','#7E2F8E'};
    figure('visible','on');
    hold on;
    if plot_params.PlotBoundary==true
        for i = 1:length(round_shape_data{r}.Boundaries)
            boundary = round_shape_data{r}.Boundaries{i};
            for c = 1:num_circles
                if ismember(i, round_shape_data{r}.CircleDataInd{num_circles-c+1})
                    line_width = num_circles-c+1;
                    break;
                end
            end
            plot(boundary(:,2),boundary(:,1),'LineWidth',line_width)
        end
    end
    if plot_params.PlotCentroid==true
        for i = 1:length(round_shape_data{r}.Centroids)
            centroid = round_shape_data{r}.Centroids{i};
            for c = 1:num_circles
                if ismember(i, round_shape_data{r}.CircleDataInd{num_circles-c+1})
                    color_index = mod(c, 5)+1;
                    plot_color = line_colors{color_index};
                    break;
                end
            end
            plot(centroid(1),centroid(2),'marker','+','color',plot_color);
        end
    end
    xlim([plot_params.TimeStart plot_params.TimeEnd])
    ylim([plot_params.FreqStart plot_params.FreqEnd])
    hold off
end
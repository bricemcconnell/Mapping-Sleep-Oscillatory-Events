function [roi_values] = GetSpectrogramROIValues(pixelbox_params, sg_data)

sg_time = sg_data.Time;
sg_freq = sg_data.Frequency;
[~, start_freq_ind] = min(abs(sg_freq-pixelbox_params.StartFrequency));
[~, end_freq_ind] = min(abs(sg_freq-pixelbox_params.EndFrequency));
[~, start_time_ind] = min(abs(sg_time-pixelbox_params.StartTime));
[~, end_time_ind] = min(abs(sg_time-pixelbox_params.EndTime));

roi_values = zeros(1, size(sg_data.IndividualSpectrograms,3));
wb = swswaitbar(0,'Please wait...', 'Name','Getting ROI Values');
ns = size(sg_data.IndividualSpectrograms,3);
for i = 1:ns
    indiv_sg_data = sg_data.IndividualSpectrograms;
    sg_box = indiv_sg_data(start_freq_ind:end_freq_ind,start_time_ind:end_time_ind,i);
    roi_values(i) = mean(sg_box(:));
    swswaitbar(i/ns, wb);
end
close(wb);

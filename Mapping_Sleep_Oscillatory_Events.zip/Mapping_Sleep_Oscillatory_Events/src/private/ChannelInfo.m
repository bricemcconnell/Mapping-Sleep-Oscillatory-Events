function [channel] = ChannelInfo(chan_file, chan_index, wt_param)
mapChanData = matfile(chan_file,'Writable',false);

%extract general data
chanList = mapChanData.ChannelStr;
chan_str = chanList(mapChanData.Channel(chan_index,:));
sr = mapChanData.SamplingRate(chan_index,:);

%no channel were selected
if isempty(sr)
    return
end

%% TODO: Consider splitting this into two separate pieces?

%convert time into samples
[start_time, end_time] = ConvertTimeToSamples(sr, ...
wt_param.StartTime, wt_param.EndTime);

% % % % % %
%remove artifacts / select portion for detection
chan_data = mapChanData.ProcessedData(chan_index,:);
%if length set too long, fix
if end_time > length(chan_data)
    fprintf('\nLength adjusted to maximum time available.\n');
    end_time = length(chan_data);
end
part = chan_data(:,start_time:end_time);

%data structure
channel = struct(...
    'Id', '',...
    'Index', chan_index, ...
    'ChanStr', chan_str, ...
    'StartTime', start_time, ...
    'EndTime', end_time, ...
    'SR', sr, ...
    'Part', part);
return